'use strict';

var url = require('url');

var User = require('./UserService');

module.exports.ispersonvalidIdGET = function ispersonvalidIdGET (req, res, next) {
  User.ispersonvalidIdGET(req.swagger.params, res, next);
};

module.exports.validpeopleGET = function validpeopleGET (req, res, next) {
  User.validpeopleGET(req.swagger.params, res, next);
};

module.exports.validpeopleIdGET = function validpeopleIdGET (req, res, next) {
  User.validpeopleIdGET(req.swagger.params, res, next);
};
