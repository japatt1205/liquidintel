'use strict';

exports.activityGET = function(args, res, next) {
  /**
   * See all pour activities
   * A session is defined by an instance that a user has scanned their badge and poured a beer. You can see information on each session including the time of pouring as well as the pour amount and beer selected. You see descriptive information on both the user and the beer
   *
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "Brewery" : "aeiou",
  "BeerType" : "aeiou",
  "PersonnelNumber" : 2,
  "UntappdCheckinID" : 7,
  "UntappdId" : 5,
  "UntappdBadgeImageURL" : "aeiou",
  "PourTime" : "aeiou",
  "BeerDescription" : "aeiou",
  "ABV" : 1.46581298050294517310021547018550336360931396484375,
  "BeerImagePath" : "aeiou",
  "Alias" : "aeiou",
  "FullName" : "aeiou",
  "PourAmount" : 6,
  "BeerName" : "aeiou",
  "SessionID" : 0,
  "IBU" : 5.962133916683182377482808078639209270477294921875,
  "UntappdBadgeName" : 9
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

