'use strict';

var url = require('url');

var Kegs = require('./KegsService');

module.exports.currentkegGET = function currentkegGET (req, res, next) {
  Kegs.currentkegGET(req.swagger.params, res, next);
};

module.exports.currentkegIdGET = function currentkegIdGET (req, res, next) {
  Kegs.currentkegIdGET(req.swagger.params, res, next);
};

module.exports.kegsGET = function kegsGET (req, res, next) {
  Kegs.kegsGET(req.swagger.params, res, next);
};
