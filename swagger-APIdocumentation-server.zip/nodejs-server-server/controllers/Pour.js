'use strict';

var url = require('url');

var Pour = require('./PourService');

module.exports.activityGET = function activityGET (req, res, next) {
  Pour.activityGET(req.swagger.params, res, next);
};
