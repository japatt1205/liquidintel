'use strict';

exports.currentkegGET = function(args, res, next) {
  /**
   * Get current kegs
   * Used to see all current kegs on the tap
   *
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "Brewery" : "aeiou",
  "BeerType" : "aeiou",
  "imagePath" : "aeiou",
  "UntappdId" : 7,
  "InstallDate" : "aeiou",
  "Name" : "aeiou",
  "KegSize" : 1,
  "BeerDescription" : "aeiou",
  "TapID" : 0,
  "ABV" : 5.63737665663332876420099637471139430999755859375,
  "KegID" : 6,
  "CurrentVolume" : 5,
  "IBU" : 2.3021358869347654518833223846741020679473876953125
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.currentkegIdGET = function(args, res, next) {
  /**
   * Gets information on specified tap
   * Returns the keg on the Tap ID specified
   *
   * id String The tapid
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "Brewery" : "aeiou",
  "BeerType" : "aeiou",
  "imagePath" : "aeiou",
  "UntappdId" : 7,
  "InstallDate" : "aeiou",
  "Name" : "aeiou",
  "KegSize" : 1,
  "BeerDescription" : "aeiou",
  "TapID" : 0,
  "ABV" : 5.63737665663332876420099637471139430999755859375,
  "KegID" : 6,
  "CurrentVolume" : 5,
  "IBU" : 2.3021358869347654518833223846741020679473876953125
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.kegsGET = function(args, res, next) {
  /**
   * Get Kegs
   * Returns a list of all registered kegs in the liquied intelligence database
   *
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "Brewery" : "aeiou",
  "BeerType" : "aeiou",
  "BeerDescription" : "aeiou",
  "ABV" : 6.02745618307040320615897144307382404804229736328125,
  "imagePath" : "aeiou",
  "KegID" : 0,
  "UntappdId" : "aeiou",
  "IBU" : 1.46581298050294517310021547018550336360931396484375,
  "Name" : "aeiou"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

