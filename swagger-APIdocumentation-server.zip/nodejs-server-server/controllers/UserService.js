'use strict';

exports.ispersonvalidIdGET = function(args, res, next) {
  /**
   * Find out if specified user is valid
   * Tells you if person is valid user of the keg
   *
   * id String The specific users cardid
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "PersonnelNumber" : 0,
  "Valid" : true,
  "FullName" : "aeiou"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.validpeopleGET = function(args, res, next) {
  /**
   * Information on specified user
   * Get information on a specific registered user
   *
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "PersonnelNumber" : 0,
  "Valid" : true,
  "FullName" : "aeiou",
  "CardId" : true
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.validpeopleIdGET = function(args, res, next) {
  /**
   * Information on specified user
   * Get information on a specific registered user
   *
   * id String The specific users cardid
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "PersonnelNumber" : 0,
  "Valid" : true,
  "FullName" : "aeiou",
  "CardId" : true
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

